package com.chromaticsketch

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import android.util.DisplayMetrics
import android.graphics.Point
import android.view.WindowManager

class DrawAccessibilityService : AccessibilityService() {
    companion object { var instance: DrawAccessibilityService? = null }
    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() { if (instance === this) instance = null; super.onDestroy() }

    fun draw(strokes: List<Stroke>) {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val size = Point(); @Suppress("DEPRECATION") wm.defaultDisplay.getRealSize(size)
        // Drawing area is the central 70% of the screen; align the target canvas there before use.
        val left = size.x * 0.15f; val top = size.y * 0.20f
        val width = size.x * 0.70f; val height = size.y * 0.60f
        Thread {
            for (s in strokes) {
                val path = Path().apply {
                    moveTo(left + s.start.x * width, top + s.start.y * height)
                    lineTo(left + s.end.x * width, top + s.end.y * height)
                }
                val gesture = GestureDescription.Builder()
                    .addStroke(GestureDescription.StrokeDescription(path, 0, 70))
                    .build()
                dispatchGesture(gesture, null, null)
                Thread.sleep(85)
            }
        }.start()
    }
}
