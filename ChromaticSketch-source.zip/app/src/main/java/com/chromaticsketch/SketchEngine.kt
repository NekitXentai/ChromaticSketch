package com.chromaticsketch

import android.graphics.Bitmap
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import kotlin.math.abs

data class Stroke(val start: Offset, val end: Offset, val color: Color)

object SketchEngine {
    private val palette = listOf(Color(0xFFFF4FA3), Color(0xFFB66BFF), Color(0xFF48E69A), Color(0xFFFFA34D), Color(0xFF48CFFF))
    fun makeStrokes(source: Bitmap): List<Stroke> {
        val w = 72
        val h = (source.height * w.toFloat() / source.width).toInt().coerceIn(1, 100)
        val b = Bitmap.createScaledBitmap(source, w, h, true)
        val out = mutableListOf<Stroke>()
        for (y in 1 until h - 1 step 2) for (x in 1 until w - 1 step 2) {
            val c = b.getPixel(x, y)
            val r = (c shr 16) and 255; val g = (c shr 8) and 255; val bl = c and 255
            val right = b.getPixel(x + 1, y); val down = b.getPixel(x, y + 1)
            val diff = abs(r - ((right shr 16) and 255)) + abs(g - ((right shr 8) and 255)) + abs(bl - (right and 255))
            val diff2 = abs(r - ((down shr 16) and 255)) + abs(g - ((down shr 8) and 255)) + abs(bl - (down and 255))
            if (diff + diff2 > 95) {
                val nx = x / w.toFloat(); val ny = y / h.toFloat()
                out.add(Stroke(Offset(nx, ny), Offset((x + 1f) / w, (y + 1f) / h), palette[((r + g + bl) / 3 / 52).coerceIn(0,4)]))
            }
        }
        return out.take(900)
    }
}
