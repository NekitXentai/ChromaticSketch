package com.chromaticsketch

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.Alignment
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SketchScreen() }
    }
}

@Composable
fun SketchScreen() {
    val ctx = LocalContext.current
    var bitmap by remember { mutableStateOf<Bitmap?>(null) }
    var preview by remember { mutableStateOf<List<Stroke>>(emptyList()) }
    var status by remember { mutableStateOf("Выбери изображение, чтобы создать цветной эскиз") }
    var running by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            try {
                ctx.contentResolver.openInputStream(uri)?.use { bitmap = BitmapFactory.decodeStream(it) }
                preview = bitmap?.let { SketchEngine.makeStrokes(it) } ?: emptyList()
                status = "Эскиз готов: ${preview.size} цветных штрихов"
            } catch (e: Exception) { status = "Не удалось открыть изображение" }
        }
    }
    MaterialTheme {
        Column(Modifier.fillMaxSize().background(Color(0xFF090D18)).padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("CHROMATIC SKETCH", color = Color(0xFF66F2FF), fontSize = 22.sp)
            Text("Фото → цветной рисунок → холст Marina", color = Color.LightGray)
            Button(onClick = { picker.launch("image/*") }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(backgroundColor = Color(0xFF202C45))) { Text("Выбрать изображение", color = Color.White) }
            Box(Modifier.weight(1f).fillMaxWidth().background(Color(0xFF121A2A), RoundedCornerShape(16.dp)).padding(8.dp), contentAlignment = Alignment.Center) {
                if (bitmap != null) Canvas(Modifier.fillMaxSize()) {
                    val img = bitmap!!.asImageBitmap()
                    drawImage(img, dstSize = androidx.compose.ui.unit.IntSize(size.width.toInt(), size.height.toInt()), alpha = 0.18f)
                    preview.forEach { s -> drawLine(s.color, s.start, s.end, strokeWidth = 3f) }
                } else Text("ПРЕДПРОСМОТР", color = Color.Gray)
            }
            Text(status, color = Color(0xFFB6C7E8))
            Button(onClick = {
                ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                status = "Включи Chromatic Sketch в специальных возможностях, затем вернись сюда"
            }, modifier = Modifier.fillMaxWidth()) { Text("1. Включить управление касаниями") }
            Button(onClick = {
                if (preview.isEmpty()) status = "Сначала выбери изображение"
                else if (DrawAccessibilityService.instance == null) status = "Сначала включи службу специальных возможностей"
                else {
                    running = true
                    DrawAccessibilityService.instance?.draw(preview)
                    status = "Отправлены штрихи. Переключись на Marina и заранее открой холст."
                }
            }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(backgroundColor = Color(0xFF8B4DFF))) { Text("2. Начать рисование", color = Color.White) }
            Text("Важно: первая версия использует координаты экрана. Перед запуском настрой масштаб холста вручную; не запускай поверх важных кнопок.", color = Color.Gray, fontSize = 12.sp)
        }
    }
}
